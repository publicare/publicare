<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Minist�rio da Ci�ncia & Tecnologia - P�gina n�o encontrada</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
#tblErro404I {
	border: 2px solid;
	border-bottom-width:0px;
	border-top-width:1px;
	border-top-color:#ddd;
	border-left-width:0px;
	border-right-width:1px;
	border-right-color:#ddd;
}
#tblErro404II {
	border: 1px solid;
	padding: 5px;
	border-bottom-width:1px;
	border-bottom-color:#ddd;
	border-top-width:0px;
	border-top-color:#ddd;
	border-left-color:#ddd;
	border-right-color:#ddd;
	border-left-width:1px;
	border-right-width:1px;
	background: url(/html/imagens/dobra_pg_.jpg) 100% 108% no-repeat;
}
div.imagemborda {


}


#imgpos {
position:absolute;
left:70.75%;
top:61.35%;
margin-left:-295;
margin-top:-20px;
}

div.centralizar {
	position:absolute;
	left:50%;
	top:60%;
	margin-left:-300px;
	margin-top:-270px;
}
</style>
</head>

<body leftmargin="0" topmargin="10" marginwidth="0" marginheight="0">

<table width="532" border="0" align="center" cellpadding="0" cellspacing="0" >
  <tr valign="top"> 
    <td height="50"></td>
  </tr>
  <tr valign="top"> 
    <td><img src="/html/imagens/topBandera1.jpg" width="532" height="31"><br> 
      <img src="/html/imagens/topBandera2.jpg" width="532" height="37"> </td>
  </tr>
  </table>
  
  <table width="532" border="0" align="center" cellpadding="0" cellspacing="0" >
  <tr valign="top"> 
    <td width="561">
      <hr size="5" style="background-color: #eee;width:100%;border:0px">
      <img src="/html/imagens/icn_erro404.jpg" width="184" height="44" vspace="5"><br> 
      <hr size="5" style="background-color: #eee;width:100%;border:0px">
      <BR>
      <font size="4" face="Arial, Helvetica, sans-serif"><strong>P�gina n�o encontrada</strong></font><BR><br>
      <font size="3" face="Arial, Helvetica, sans-serif">
      O seu navegador n�o p�de exibir a p�gina solicitada.</font> 
      <br> </td>
  </tr>
</table>

<!--<img src="/html/imagens/dobra_pg.jpg" width="285" height="82" title="logo de 220 por 80 pixel" id="imgpos">-->


</body>
</html>
