<br><br>
<div align="center"><img src="/html/imagens/icn_exclamacao.gif" hspace="3" align="absmiddle" width="14" height="14"><b>Aten��o</b>: Voc� est� tentando acessar uma �rea restrita do website.</div><br>
<form action="/security/login_post.php?obj=<@ eco $cod_objeto@>" method="POST" name="frmDinamico">
<table width="416" border="0" cellspacing="0" cellpadding="5" style="border:#CCCCCC 1px solid;" align="center" class="login">
  <tr>
    <td width="404" valign="top"> 
      <table width="404" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="25"></td>
          <td width="100" rowspan="11" valign="top"><img src="/html/imagens/icn_login.jpg" class="imgLogin" border="0"></td>
          <td width="89">&nbsp;</td>
          <td width="190">&nbsp;</td>
        </tr>
        <tr> 
          <td bgcolor="E4E8D0" class="tdDadosUsuario"></td>
          <td colspan="2" bgcolor="E4E8D0" style="font-size:13px"><strong>&nbsp;&nbsp;&nbsp;Dados do usu&aacute;rio:</strong></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td align="right"><strong>Usu&aacute;rio</strong>:</td>
          <td>&nbsp;&nbsp;<input type="text" name="login" class="cxLogin"></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td align="right"><strong>Senha</strong>:</td>
          <td>&nbsp;&nbsp;<input type="password" name="password" class="cxLogin"></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td align="right"><a href="JavaScript:frmDinamico.submit();"><img src="/html/imagens/btn_enviar.jpg" width="57" height="16" hspace="50" border="0"></a></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td colspan="2" align="right" valign="bottom"><img src="/html/imagens/icn_arearestrita.jpg" width="81" height="20"></td>
        </tr>
      </table></td>
  </tr>
</table>